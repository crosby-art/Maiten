# Sistema de Gestión — Prototipo de Interfaces de Administración

## Descripción

Este proyecto es un **prototipo navegable** de las interfaces web para la administración de servicios, contratos y reportes de una organización. El sistema permite a los usuarios gestionar servicios, importar cobranzas, visualizar asociados y generar certificados de adhesión en PDF con código QR.  

El prototipo fue desarrollado como parte de la **Actividad 4 — Diseño de Interfaces de Administración**, permitiendo interactuar con la base de datos desarrollada por el equipo de Backend/BD.

---

## Objetivo

Prototipar y diseñar las pantallas que operarán sobre la base de datos, facilitando las operaciones de:

- **Alta, edición y baja de servicios.**
- **Búsqueda de registros** con filtros por entidad, servicio y estado, con opción de exportar resultados a Excel.
- **Importación de cobranzas** y visualización de servicios en mora.
- **Generación de certificados de adhesión** en PDF con código QR y datos del asociado.

---

## Tecnologías Utilizadas

- **Frontend:** React, TypeScript, HTML5, CSS3, Bootstrap 5  
- **Editor:** Visual Studio Code  
- **Herramientas de prototipado:** Navegador web moderno para pruebas de interfaz  

---

## Estructura del Proyecto



## Instalación y Uso

1. **Clonar el repositorio:**

git clone https://github.com/usuario/proyecto-interfaces.git

2. **Abrir el proyecto en Visual Studio Code**
-Abrir la carpeta del proyecto.
-Instalar dependencias (si se agregan librerías de React/TypeScript):
npm install

3. **Ejecutar el proyecto en modo desarrollo**

Ejecutar el proyecto en modo desarrollo:

npm start


Abrir en navegador:

El proyecto estará disponible típicamente en http://localhost:3000 para visualizar y navegar las interfaces.
```bash